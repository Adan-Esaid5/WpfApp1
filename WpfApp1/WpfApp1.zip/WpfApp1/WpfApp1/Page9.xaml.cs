﻿using System;
using System.Windows;
using System.Windows.Controls;

namespace HebrewFormApp
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            InitializeControls();
        }

        private void InitializeControls()
        {
            // Set current date values
            var currentDate = DateTime.Now;

            // You can add more initialization code here
            // For example, populating comboboxes with data
        }
    }
}
