﻿
using System.IO;

namespace ExcelDataImporter
{
    internal class ExcelPackage : IDisposable
    {
        internal object Workbook;

        public ExcelPackage(FileInfo fileInfo)
        {
            FileInfo = fileInfo;
        }

        public FileInfo FileInfo { get; }
    }
}