﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using Microsoft.Win32;

namespace TrafficManagement
{
    public partial class ManualCounterSetupDialog : Window
    {
        // Dictionary to store file paths for each direction
        private Dictionary<string, string> directionFilePaths;

        public ManualCounterSetupDialog()
        {
            InitializeComponent();

            // Initialize the dictionary
            directionFilePaths = new Dictionary<string, string>
            {
                { "דרום צפון", string.Empty },
                { "דרום דרום", string.Empty },
                { "דרום מזרח", string.Empty },
                { "דרום מערב", string.Empty }
            };
        }

        private void BrowseFile_Click(object sender, RoutedEventArgs e)
        {
            // Get the button that was clicked
            Button button = sender as Button;
            if (button == null) return;

            // Get the parent grid
            Grid parentGrid = button.Parent as Grid;
            if (parentGrid == null) return;

            // Get the direction text block and text box
            TextBlock directionTextBlock = parentGrid.Children[0] as TextBlock;
            TextBox filePathTextBox = parentGrid.Children[2] as TextBox;
            CheckBox dataExistsCheckBox = parentGrid.Children[1] as CheckBox;

            if (directionTextBlock == null || filePathTextBox == null || dataExistsCheckBox == null) return;

            // Get the direction
            string direction = directionTextBlock.Text;

            // Show file dialog
            OpenFileDialog openFileDialog = new OpenFileDialog
            {
                Filter = "Excel Files|*.xlsx;*.xls|CSV Files|*.csv|All Files|*.*",
                Title = $"בחר קובץ נתונים עבור {direction}"
            };

            if (openFileDialog.ShowDialog() == true)
            {
                // Update the text box and dictionary
                filePathTextBox.Text = openFileDialog.FileName;
                directionFilePaths[direction] = openFileDialog.FileName;

                // Check the "data exists" checkbox
                dataExistsCheckBox.IsChecked = true;
            }
        }

        private void AddData_Click(object sender, RoutedEventArgs e)
        {
            // Get the button that was clicked
            Button button = sender as Button;
            if (button == null) return;

            // Get the parent grid
            Grid parentGrid = button.Parent as Grid;
            if (parentGrid == null) return;

            // Get the direction text block and checkbox
            TextBlock directionTextBlock = parentGrid.Children[0] as TextBlock;
            CheckBox dataExistsCheckBox = parentGrid.Children[1] as CheckBox;

            if (directionTextBlock == null || dataExistsCheckBox == null) return;

            // Get the direction
            string direction = directionTextBlock.Text;

            // Check if data exists
            if (dataExistsCheckBox.IsChecked == true)
            {
                // Open data entry dialog or process the file
                // This would be implemented based on your application's requirements
                MessageBox.Show($"מוסיף נתונים עבור {direction}", "הוספת נתונים", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            else
            {
                MessageBox.Show("אנא סמן 'קיים מידע' או בחר קובץ תחילה.", "שגיאה", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            // Check if any data exists
            bool hasData = false;
            foreach (var grid in FindVisualChildren<Grid>(this))
            {
                if (grid.RowDefinition != null && grid.RowDefinition.Parent == this.Content)
                {
                    foreach (var checkbox in FindVisualChildren<CheckBox>(grid))
                    {
                        if (checkbox.IsChecked == true)
                        {
                            hasData = true;
                            break;
                        }
                    }

                    if (hasData) break;
                }
            }

            // If data exists, ask for confirmation
            if (hasData)
            {
                MessageBoxResult result = MessageBox.Show(
                    "האם אתה בטוח שברצונך לסגור? כל הנתונים שלא נשמרו יאבדו.",
                    "אישור סגירה",
                    MessageBoxButton.YesNo,
                    MessageBoxImage.Question);

                if (result == MessageBoxResult.No)
                {
                    return;
                }
            }

            // Close the dialog
            this.Close();
        }

        // Helper method to find visual children of a specific type
        private static IEnumerable<T> FindVisualChildren<T>(DependencyObject depObj) where T : DependencyObject
        {
            if (depObj != null)
            {
                for (int i = 0; i < VisualTreeHelper.GetChildrenCount(depObj); i++)
                {
                    DependencyObject child = VisualTreeHelper.GetChild(depObj, i);
                    if (child != null && child is T)
                    {
                        yield return (T)child;
                    }

                    foreach (T childOfChild in FindVisualChildren<T>(child))
                    {
                        yield return childOfChild;
                    }
                }
            }
        }
    }
}