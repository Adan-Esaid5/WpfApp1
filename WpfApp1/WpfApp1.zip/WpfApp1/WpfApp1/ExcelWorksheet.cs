﻿namespace ExcelDataImporter
{
    internal class ExcelWorksheet
    {
        internal readonly object Cells;

        public object Dimension { get; internal set; }
    }
}